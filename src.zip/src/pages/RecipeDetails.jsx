function RecipeDetailsPage() {
    
    return (
        <>
            <div>
                <div>
                    <h2>Recipe name</h2>
                    <img src="" alt="" />
                    <p>calories</p>
                    <p>servings</p>
                </div>
            </div>
            <button>Back</button>
        </>
    )
}

export default RecipeDetailsPage