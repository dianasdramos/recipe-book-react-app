function About() {
    return (
        <div>
            <h3>Insert text</h3>
            <p>Insert text</p>
        </div>
    )
}

export default About