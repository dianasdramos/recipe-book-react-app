function Navbar() {


    return (
        <nav>
            <div>
                <a href=""><img src="" alt="" /></a>
            </div>
            <div>
                <h3><b></b></h3>
            </div>
            <div>
                <a href=""><img src="" alt="" /></a>
                <a href=""><img src="" alt="" /></a>
                <a href=""><img src="" alt="" /></a>
            </div>
        </nav>
    )

}

export default Navbar;